#include "Snake.h"
int main(void)
{
	gameFlow();
	return 0;
}
