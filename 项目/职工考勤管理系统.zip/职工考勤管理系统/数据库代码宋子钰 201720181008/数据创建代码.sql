--�������ݿ�
USE [master]
GO

/****** Object:  Database [db_StaffInfo]    Script Date: 01/03/2019 22:42:41 ******/
CREATE DATABASE [db_StaffInfo] ON  PRIMARY 
( NAME = N'Staff_data', FILENAME = N'C:\Users\10799\Desktop\dataBase\Staff_data.mdf' , SIZE = 5120KB , MAXSIZE = 51200KB , FILEGROWTH = 1%)
 LOG ON 
( NAME = N'Staff_log', FILENAME = N'C:\Users\10799\Desktop\dataBase\Staff_data.ldf' , SIZE = 1024KB , MAXSIZE = 10240KB , FILEGROWTH = 1024KB )
GO

ALTER DATABASE [db_StaffInfo] SET COMPATIBILITY_LEVEL = 100
GO

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [db_StaffInfo].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO

ALTER DATABASE [db_StaffInfo] SET ANSI_NULL_DEFAULT OFF 
GO

ALTER DATABASE [db_StaffInfo] SET ANSI_NULLS OFF 
GO

ALTER DATABASE [db_StaffInfo] SET ANSI_PADDING OFF 
GO

ALTER DATABASE [db_StaffInfo] SET ANSI_WARNINGS OFF 
GO

ALTER DATABASE [db_StaffInfo] SET ARITHABORT OFF 
GO

ALTER DATABASE [db_StaffInfo] SET AUTO_CLOSE OFF 
GO

ALTER DATABASE [db_StaffInfo] SET AUTO_CREATE_STATISTICS ON 
GO

ALTER DATABASE [db_StaffInfo] SET AUTO_SHRINK OFF 
GO

ALTER DATABASE [db_StaffInfo] SET AUTO_UPDATE_STATISTICS ON 
GO

ALTER DATABASE [db_StaffInfo] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO

ALTER DATABASE [db_StaffInfo] SET CURSOR_DEFAULT  GLOBAL 
GO

ALTER DATABASE [db_StaffInfo] SET CONCAT_NULL_YIELDS_NULL OFF 
GO

ALTER DATABASE [db_StaffInfo] SET NUMERIC_ROUNDABORT OFF 
GO

ALTER DATABASE [db_StaffInfo] SET QUOTED_IDENTIFIER OFF 
GO

ALTER DATABASE [db_StaffInfo] SET RECURSIVE_TRIGGERS OFF 
GO

ALTER DATABASE [db_StaffInfo] SET  ENABLE_BROKER 
GO

ALTER DATABASE [db_StaffInfo] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO

ALTER DATABASE [db_StaffInfo] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO

ALTER DATABASE [db_StaffInfo] SET TRUSTWORTHY OFF 
GO

ALTER DATABASE [db_StaffInfo] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO

ALTER DATABASE [db_StaffInfo] SET PARAMETERIZATION SIMPLE 
GO

ALTER DATABASE [db_StaffInfo] SET READ_COMMITTED_SNAPSHOT OFF 
GO

ALTER DATABASE [db_StaffInfo] SET HONOR_BROKER_PRIORITY OFF 
GO

ALTER DATABASE [db_StaffInfo] SET  READ_WRITE 
GO

ALTER DATABASE [db_StaffInfo] SET RECOVERY FULL 
GO

ALTER DATABASE [db_StaffInfo] SET  MULTI_USER 
GO

ALTER DATABASE [db_StaffInfo] SET PAGE_VERIFY CHECKSUM  
GO

ALTER DATABASE [db_StaffInfo] SET DB_CHAINING OFF 
GO


--�������ݱ�
--���������
USE [db_StaffInfo]
GO

/****** Object:  Table [dbo].[BusinessTripInfo]    Script Date: 01/03/2019 22:43:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[BusinessTripInfo](
	[start] [datetime] NOT NULL,
	[endTime] [datetime] NOT NULL,
	[total] [real] NOT NULL,
	[allowance] [money] NULL,
	[id] [char](6) NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[BusinessTripInfo]  WITH CHECK ADD  CONSTRAINT [FK__BusinessTrip__id__08EA5793] FOREIGN KEY([id])
REFERENCES [dbo].[StaffInfo] ([id])
GO

ALTER TABLE [dbo].[BusinessTripInfo] CHECK CONSTRAINT [FK__BusinessTrip__id__08EA5793]
GO

ALTER TABLE [dbo].[BusinessTripInfo]  WITH CHECK ADD CHECK  (([allowance]>=(0)))
GO

--������ٱ�
USE [db_StaffInfo]
GO

/****** Object:  Table [dbo].[LeaveInfo]    Script Date: 01/03/2019 22:44:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[LeaveInfo](
	[start] [datetime] NOT NULL,
	[endTime] [datetime] NOT NULL,
	[total] [real] NOT NULL,
	[deduction] [money] NULL,
	[id] [char](6) NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[LeaveInfo]  WITH CHECK ADD  CONSTRAINT [FK__LeaveInfo__id__060DEAE8] FOREIGN KEY([id])
REFERENCES [dbo].[StaffInfo] ([id])
GO

ALTER TABLE [dbo].[LeaveInfo] CHECK CONSTRAINT [FK__LeaveInfo__id__060DEAE8]
GO

ALTER TABLE [dbo].[LeaveInfo]  WITH CHECK ADD CHECK  (([deduction]>=(0)))
GO


--�����Ӱ��
USE [db_StaffInfo]
GO

/****** Object:  Table [dbo].[OverTimeInfo]    Script Date: 01/03/2019 22:44:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[OverTimeInfo](
	[start] [datetime] NOT NULL,
	[endTime] [datetime] NOT NULL,
	[total] [real] NOT NULL,
	[overTimeWage] [money] NULL,
	[id] [char](6) NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[OverTimeInfo]  WITH CHECK ADD  CONSTRAINT [FK__OverTimeInfo__id__0BC6C43E] FOREIGN KEY([id])
REFERENCES [dbo].[StaffInfo] ([id])
GO

ALTER TABLE [dbo].[OverTimeInfo] CHECK CONSTRAINT [FK__OverTimeInfo__id__0BC6C43E]
GO

ALTER TABLE [dbo].[OverTimeInfo]  WITH CHECK ADD CHECK  (([overTimeWage]>=(0)))
GO


--����ְ����Ϣ��
USE [db_StaffInfo]
GO

/****** Object:  Table [dbo].[StaffInfo]    Script Date: 01/03/2019 22:45:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[StaffInfo](
	[id] [char](6) NOT NULL,
	[name] [varchar](12) NOT NULL,
	[sex] [char](2) NOT NULL,
	[birthday] [datetime] NOT NULL,
	[title] [varchar](12) NULL,
 CONSTRAINT [PK__StaffInf__3213E83F7F60ED59] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[StaffInfo]  WITH CHECK ADD  CONSTRAINT [CK__StaffInfo__sex__014935CB] CHECK  (([sex]='Ů' OR [sex]='��'))
GO

ALTER TABLE [dbo].[StaffInfo] CHECK CONSTRAINT [CK__StaffInfo__sex__014935CB]
GO

ALTER TABLE [dbo].[StaffInfo]  WITH CHECK ADD  CONSTRAINT [CK_StaffInfo_id] CHECK  ((len([id])=(6)))
GO

ALTER TABLE [dbo].[StaffInfo] CHECK CONSTRAINT [CK_StaffInfo_id]
GO

ALTER TABLE [dbo].[StaffInfo] ADD  CONSTRAINT [DF_StaffInfo_title]  DEFAULT ('��ְͨ��') FOR [title]
GO

--�����û���
USE [db_StaffInfo]
GO

/****** Object:  Table [dbo].[UserInfo]    Script Date: 01/03/2019 22:45:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[UserInfo](
	[Tel] [char](11) NOT NULL,
	[id] [char](6) NOT NULL,
	[userName] [varchar](20) NOT NULL,
	[passWd] [char](16) NOT NULL,
	[userType] [bit] NOT NULL,
 CONSTRAINT [PK_UserInfo_1] PRIMARY KEY CLUSTERED 
(
	[Tel] ASC,
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[UserInfo]  WITH CHECK ADD  CONSTRAINT [FK_UserInfo_StaffInfo] FOREIGN KEY([id])
REFERENCES [dbo].[StaffInfo] ([id])
GO

ALTER TABLE [dbo].[UserInfo] CHECK CONSTRAINT [FK_UserInfo_StaffInfo]
GO

ALTER TABLE [dbo].[UserInfo]  WITH CHECK ADD  CONSTRAINT [CK_UserInfo] CHECK  ((len([Tel])=(11)))
GO

ALTER TABLE [dbo].[UserInfo] CHECK CONSTRAINT [CK_UserInfo]
GO

ALTER TABLE [dbo].[UserInfo]  WITH CHECK ADD  CONSTRAINT [CK_UserInfo_len_passWord] CHECK  ((len([passWd])>=(8)))
GO

ALTER TABLE [dbo].[UserInfo] CHECK CONSTRAINT [CK_UserInfo_len_passWord]
GO

ALTER TABLE [dbo].[UserInfo]  WITH CHECK ADD  CONSTRAINT [CK_UserInfo_Name_len] CHECK  ((len([userName])>(3)))
GO

ALTER TABLE [dbo].[UserInfo] CHECK CONSTRAINT [CK_UserInfo_Name_len]
GO


--�������ʱ�
USE [db_StaffInfo]
GO

/****** Object:  Table [dbo].[WageInfo]    Script Date: 01/03/2019 22:45:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[WageInfo](
	[base] [money] NOT NULL,
	[overTimeWage] [money] NULL,
	[absentDeduction] [money] NULL,
	[leaveDeduction] [money] NULL,
	[allowance] [money] NULL,
	[total] [money] NULL,
	[id] [char](6) NOT NULL,
	[start] [datetime] NULL,
	[endTime] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[WageInfo]  WITH CHECK ADD  CONSTRAINT [FK__WageInfo__id__1273C1CD] FOREIGN KEY([id])
REFERENCES [dbo].[StaffInfo] ([id])
GO

ALTER TABLE [dbo].[WageInfo] CHECK CONSTRAINT [FK__WageInfo__id__1273C1CD]
GO

ALTER TABLE [dbo].[WageInfo]  WITH CHECK ADD  CONSTRAINT [CK__WageInfo__absent__0F975522] CHECK  (([absentDeduction]>=(0)))
GO

ALTER TABLE [dbo].[WageInfo] CHECK CONSTRAINT [CK__WageInfo__absent__0F975522]
GO

ALTER TABLE [dbo].[WageInfo]  WITH CHECK ADD  CONSTRAINT [CK__WageInfo__allowa__117F9D94] CHECK  (([allowance]>=(0)))
GO

ALTER TABLE [dbo].[WageInfo] CHECK CONSTRAINT [CK__WageInfo__allowa__117F9D94]
GO

ALTER TABLE [dbo].[WageInfo]  WITH CHECK ADD  CONSTRAINT [CK__WageInfo__base__0DAF0CB0] CHECK  (([base]>=(0)))
GO

ALTER TABLE [dbo].[WageInfo] CHECK CONSTRAINT [CK__WageInfo__base__0DAF0CB0]
GO

ALTER TABLE [dbo].[WageInfo]  WITH CHECK ADD  CONSTRAINT [CK__WageInfo__leaveD__108B795B] CHECK  (([leaveDeduction]>=(0)))
GO

ALTER TABLE [dbo].[WageInfo] CHECK CONSTRAINT [CK__WageInfo__leaveD__108B795B]
GO

ALTER TABLE [dbo].[WageInfo]  WITH CHECK ADD  CONSTRAINT [CK__WageInfo__overTi__0EA330E9] CHECK  (([overTimeWage]>=(0)))
GO

ALTER TABLE [dbo].[WageInfo] CHECK CONSTRAINT [CK__WageInfo__overTi__0EA330E9]
GO


--�������ڱ�
USE [db_StaffInfo]
GO

/****** Object:  Table [dbo].[WorkAttendanceInfo]    Script Date: 01/03/2019 22:46:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[WorkAttendanceInfo](
	[goToWork] [datetime] NULL,
	[knockOff] [datetime] NULL,
	[id] [char](6) NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[WorkAttendanceInfo]  WITH CHECK ADD  CONSTRAINT [FK__WorkAttendan__id__03317E3D] FOREIGN KEY([id])
REFERENCES [dbo].[StaffInfo] ([id])
GO

ALTER TABLE [dbo].[WorkAttendanceInfo] CHECK CONSTRAINT [FK__WorkAttendan__id__03317E3D]
GO


--���������������
USE [db_StaffInfo]
GO

/****** Object:  Trigger [dbo].[tg_BTI_Check]    Script Date: 01/03/2019 22:46:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create trigger [dbo].[tg_BTI_Check] --���ڼ���¼�Ƿ����ֵ�һ���˳���ʱ�ٴ����Ӽ�¼
on [dbo].[BusinessTripInfo]
instead of insert, update
as
	--��ȡ����Ա����id
	declare @id char(6)
	select @id = id from inserted
	--���Ѵ��ڸ�Ա��id
	if EXISTS(select * from BusinessTripInfo where id = @id)
	begin 
		--����¼�¼�Ƿ�����߼�
		declare @start datetime
		select @start = start from inserted
		--����ÿһ����¼�Ŀ�ʼʱ�����ʱ��
		declare @start_each datetime
		declare @end_each datetime
		--�����α�
		declare c1 cursor for select start, endTime from BusinessTripInfo where @id = id
		open c1
		fetch next from c1 into @start_each, @end_each	
		while @@FETCH_STATUS = 0
		begin 
			if @start >= @start_each and @start <= @end_each
				begin 
					print @id + 'ְ�����ڳ���!'
					rollback
					return 
				end
			fetch next from c1 into @start_each, @end_each
		end
		close c1
		deallocate c1
		--������Ҫ������в���
		insert into BusinessTripInfo select * from inserted
	end
	else
		insert into BusinessTripInfo select * from inserted

GO


USE [db_StaffInfo]
GO

/****** Object:  Trigger [dbo].[tg_BTI_Time]    Script Date: 01/03/2019 22:47:02 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create trigger [dbo].[tg_BTI_Time]
on [dbo].[BusinessTripInfo]
for insert, update
as
	declare @endTime  datetime
	declare @start datetime
	declare @totalReal real
	declare @total real
	select @endTime = endTime, @start = start, @totalReal = datediff(day, start, endTime),
	@total = total from inserted
	if @endTime <= @start
		begin
			print '����ʱ�䲻�����ڿ�ʼʱ��!'
			rollback
		end
	if @total != @totalReal
		begin
			print '����������ʵ��!'
			rollback
		end

GO


USE [db_StaffInfo]
GO

/****** Object:  Trigger [dbo].[tg_BTI_wage]    Script Date: 01/03/2019 22:47:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[tg_BTI_wage]
   ON  [dbo].[BusinessTripInfo]
   for insert
AS 
BEGIN
	
	--�Ȼ�ȡʱ������Ӧ��������
	declare @start datetime
	declare @month int
	declare @year int
	declare @day int 
	--��ȡ����
	declare @allowance money
	--��ȡid
	declare @id char(6)
	select @month = month(start), @year = year(start) 
		,@allowance = allowance, @id = id,
		@day = day(start),
		@start = start from inserted
	--Ҫ�Ǹ��·ݲ����ڼ�¼
	if not exists(select * from wageInfo where @month = month(start) and @year = year(start))
	begin
		--�����¼�¼
		--���㿪ʼʱ��
		declare @newStart datetime
		select @newStart = dateadd(day, -day(@start) + 1, @start)
		--�������ʱ��
		declare @end datetime
		select @end = dateadd(day, -day(@start), dateadd(m, 1, @start))
		insert into WageInfo values('4000', 0, 0, 0, @allowance, NULL, @id, @newStart, @end)
	end
	else
	--���Ѵ��ڵļ�¼�����޸�
	begin
		declare @newStart1 datetime
		select @newStart1 = dateadd(day, -day(@start) + 1, @start)
		update WageInfo set allowance = allowance + @allowance
		where id = @id and start = @newStart1
	end
END

GO


--������ٱ�������
USE [db_StaffInfo]
GO

/****** Object:  Trigger [dbo].[tg_LI_check]    Script Date: 01/03/2019 22:47:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create trigger [dbo].[tg_LI_check]
on [dbo].[LeaveInfo]
instead of insert, update
as
	--�Ȼ���������е�ְ�����
	declare @id char(6)
	select @id = id from inserted
	--�ж��Ƿ��Ѿ����ڸ�ְ����¼
	if exists(select * from LeaveInfo where @id = id)
		begin
			--��ȡ�������еĿ�ʼʱ��
			declare @start datetime
			select @start = start from inserted
			--�ж��������Ƿ�����߼�
			declare @start_each datetime
			declare @end_each datetime
			--�����α�
			declare c1 cursor for select start, endTime from LeaveInfo where @id = id
			--���α�
			open c1
			--ʹ���α�
			fetch next from c1 into @start_each, @end_each
			while @@FETCH_STATUS = 0
			begin 
				if @start >= @start_each and @start <= @end_each
					begin
						print @id + 'ְ�������ݼ�!'
						rollback
						return
					end 
			fetch next from c1 into @start_each, @end_each
			end
			--�ر��α�
			close c1
			--�ͷ��α�
			deallocate c1
			--�����������
			insert into LeaveInfo select * from inserted
		end
	else
		insert into LeaveInfo select * from inserted

GO


USE [db_StaffInfo]
GO

/****** Object:  Trigger [dbo].[tg_LI_Time]    Script Date: 01/03/2019 22:48:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create trigger [dbo].[tg_LI_Time]
on [dbo].[LeaveInfo]
for insert, update
as
	declare @endTime  datetime
	declare @start datetime
	declare @totalReal real
	declare @total real
	select @endTime = endTime, @start = start, @totalReal = datediff(day, start, endTime),
	@total = total from inserted
	if @endTime <= @start
		begin
			print '����ʱ�䲻�����ڿ�ʼʱ��!'
			rollback
		end
	if @total != @totalReal
		begin
			print '����������ʵ��!'
			rollback
		end

GO


USE [db_StaffInfo]
GO

/****** Object:  Trigger [dbo].[tg_LI_Wage]    Script Date: 01/03/2019 22:48:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[tg_LI_Wage]
   ON  [dbo].[LeaveInfo]
   for insert
AS 
BEGIN
	--�Ȼ�ȡʱ������Ӧ��������
	declare @start datetime
	declare @month int
	declare @year int
	declare @day int 
	--��ȡ����
	declare @deduction money
	--��ȡid
	declare @id char(6)
	select @month = month(start), @year = year(start) 
		,@deduction = deduction, @id = id,
		@day = day(start),
		@start = start from inserted
	--Ҫ�Ǹ��·ݲ����ڼ�¼
	if not exists(select * from wageInfo where @month = month(start) and @year = year(start))
	begin
		--�����¼�¼
		--���㿪ʼʱ��
		declare @newStart datetime
		select @newStart = dateadd(day, -day(@start) + 1, @start)
		--�������ʱ��
		declare @end datetime
		select @end = dateadd(day, -day(@start), dateadd(m, 1, @start))
		insert into WageInfo values('4000', 0, 0, @deduction, 0, NULL, @id, @newStart, @end)
	end
	else
	--���Ѵ��ڵļ�¼�����޸�
	begin
		declare @newStart1 datetime
		select @newStart1 = dateadd(day, -day(@start) + 1, @start)
		update WageInfo set leaveDeduction = leaveDeduction + @deduction
		where id = @id and start = @newStart1
	end
END


GO


--�����Ӱ��������
USE [db_StaffInfo]
GO

/****** Object:  Trigger [dbo].[tg_OT_check]    Script Date: 01/03/2019 22:48:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create trigger [dbo].[tg_OT_check]
on [dbo].[OverTimeInfo]
instead of insert, update
as
	--�Ȼ���������е�ְ�����
	declare @id char(6)
	select @id = id from inserted
	--�ж��Ƿ��Ѿ����ڸ�ְ����¼
	if exists(select * from OverTimeInfo where @id = id)
		begin
			--��ȡ�������еĿ�ʼʱ��
			declare @start datetime
			select @start = start from inserted
			--�ж��������Ƿ�����߼�
			declare @start_each datetime
			declare @end_each datetime
			--�����α�
			declare c1 cursor for select start, endTime from OverTimeInfo where @id = id
			--���α�
			open c1
			--ʹ���α�
			fetch next from c1 into @start_each, @end_each
			while @@FETCH_STATUS = 0
			begin 
				if @start >= @start_each and @start <= @end_each
					begin
						print @id + 'ְ�����ڼӰ�!'
						rollback
						return
					end 
			fetch next from c1 into @start_each, @end_each
			end
			--�ر��α�
			close c1
			--�ͷ��α�
			deallocate c1
			--�����������
			insert into OverTimeInfo select * from inserted
		end
	else
		insert into OverTimeInfo select * from inserted

GO


USE [db_StaffInfo]
GO

/****** Object:  Trigger [dbo].[tg_OTI_time]    Script Date: 01/03/2019 22:48:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE trigger [dbo].[tg_OTI_time]
on [dbo].[OverTimeInfo]
for insert, update
as
	declare @endTime  datetime
	declare @start datetime
	declare @totalReal real
	declare @total real
	select @endTime = endTime, @start = start, @totalReal = datediff(hh, start, endTime),
	@total = total from inserted
	if @endTime <= @start
		begin
			print '����ʱ�䲻�����ڿ�ʼʱ��!'
			rollback
		end
	if @total != @totalReal
		begin
			print '��ʱ������ʵ��!'
			rollback
		end

GO


USE [db_StaffInfo]
GO

/****** Object:  Trigger [dbo].[tg_OTI_wage]    Script Date: 01/03/2019 22:49:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[tg_OTI_wage]
   ON [dbo].[OverTimeInfo]
   for insert 
AS 
begin
	--�Ȼ�ȡʱ������Ӧ��������
	declare @start datetime
	declare @month int
	declare @year int
	declare @day int 
	--��ȡ�Ӱ���
	declare @overTimeWage money
	--��ȡid
	declare @id char(6)
	select @month = month(start), @year = year(start) 
		,@overTimeWage = overTimeWage, @id = id,
		@day = day(start),
		@start = start from inserted
	--Ҫ�Ǹ��·ݲ����ڼ�¼
	if not exists(select * from wageInfo where @month = month(start) and @year = year(start))
	begin
		--�����¼�¼
		--���㿪ʼʱ��
		declare @newStart datetime
		select @newStart = dateadd(day, -day(@start) + 1, @start)
		--�������ʱ��
		declare @end datetime
		select @end = dateadd(day, -day(@start), dateadd(m, 1, @start))
		insert into WageInfo values('4000', @overTimeWage, 0, 0, 0, NULL, @id, @newStart, @end)
	end
	else
	--���Ѵ��ڵļ�¼�����޸�
	begin
		declare @newStart1 datetime
		select @newStart1 = dateadd(day, -day(@start) + 1, @start)
		update WageInfo set overTimeWage = overTimeWage + @overTimeWage
		where id = @id and start = @newStart1
	end
END

GO

--����ְ����Ϣ������
USE [db_StaffInfo]
GO

/****** Object:  Trigger [dbo].[tg_SI_Age]    Script Date: 01/03/2019 22:49:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create trigger [dbo].[tg_SI_Age]
on [dbo].[StaffInfo]
for insert, update
as
	declare @ages int
	declare @sex char(2)
	select @ages = datediff(year, birthday, getdate()),  
		@sex = sex from inserted
	if (@sex = '��')
		begin	
			if (@ages > 65)
				begin 
					print '����������������!'
					rollback
				end
		end
	else
		begin
			if (@ages > 60)
				begin 
					print '����������������!'
					rollback
				end
		end

GO

USE [db_StaffInfo]
GO

/****** Object:  Trigger [dbo].[tg_SI_delete]    Script Date: 01/03/2019 22:49:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER  [dbo].[tg_SI_delete]
   ON  [dbo].[StaffInfo]
instead of delete
AS 
BEGIN
	declare @id char(6)
	select @id = id from deleted
	--ɾ�����
	delete from BusinessTripInfo
	where id = @id
	delete from LeaveInfo
	where id = @id
	delete from OverTimeInfo
	where id = @id
	delete from UserInfo
	where id = @id
	delete from WageInfo
	where id = @id
	delete from WorkAttendanceInfo
	where id = @id
	delete from StaffInfo
	where id = @id
	
END

GO


--�������ʱ�������
USE [db_StaffInfo]
GO

/****** Object:  Trigger [dbo].[tg_WI_time]    Script Date: 01/03/2019 22:50:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create trigger [dbo].[tg_WI_time]
on [dbo].[WageInfo]
for insert, update
as
	declare @endTime  datetime
	declare @start datetime
	select @endTime = endTime, @start = start from inserted
	if @endTime <= @start
		begin
			print '����ʱ�䲻�����ڿ�ʼʱ��!'
			rollback
		end


GO


USE [db_StaffInfo]
GO

/****** Object:  Trigger [dbo].[tg_WI_Total]    Script Date: 01/03/2019 22:50:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[tg_WI_Total]
   ON  [dbo].[WageInfo]
   for INSERT,UPDATE
AS 
BEGIN
	update WageInfo
	set total = base + overTimeWage - absentDeduction
	- leaveDeduction + allowance
END


GO


--�������ڱ�������
USE [db_StaffInfo]
GO

/****** Object:  Trigger [dbo].[tg_WAI_check]    Script Date: 01/03/2019 22:50:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create trigger [dbo].[tg_WAI_check]
on [dbo].[WorkAttendanceInfo]
instead of insert, update
as
	--�Ȼ���������е�ְ�����
	declare @id char(6)
	select @id = id from inserted
	--�ж��Ƿ��Ѿ����ڸ�ְ����¼
	if exists(select * from WorkAttendanceInfo where @id = id)
		begin
			--��ȡ�������еĿ�ʼʱ��
			declare @start datetime
			select @start = goToWork from inserted
			--�ж��������Ƿ�����߼�
			declare @start_each datetime
			declare @end_each datetime
			--�����α�
			declare c1 cursor for select goToWork, knockOff from WorkAttendanceInfo where @id = id
			--���α�
			open c1
			--ʹ���α�
			fetch next from c1 into @start_each, @end_each
			while @@FETCH_STATUS = 0
			begin 
				if @start >= @start_each and @start <= @end_each
					begin
						print '��' + convert(varchar(100), @start_each, 108) + '��' + convert(varchar(100), @end_each, 108) 
								+'�ڼ�' + @id + 'ְ�����д򿨼�¼!'
						rollback
						return
					end 
			fetch next from c1 into @start_each, @end_each
			end
			--�ر��α�
			close c1
			--�ͷ��α�
			deallocate c1
			--�����������
			insert into WorkAttendanceInfo select * from inserted
		end
	else
		insert into WorkAttendanceInfo select * from inserted

GO


USE [db_StaffInfo]
GO

/****** Object:  Trigger [dbo].[tg_WAI_time]    Script Date: 01/03/2019 22:50:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create trigger [dbo].[tg_WAI_time]
on [dbo].[WorkAttendanceInfo]
for insert, update
as
	declare @goToWork datetime
	declare @knockOff datetime
	select @goToWork = goToWork, @knockOff = knockOff from inserted
	if (@goToWork >= @knockOff)
		begin
			print '�°�ʱ�䲻�������ϰ�ʱ��!'
			rollback
		end

GO


--������������ͼ
USE [db_StaffInfo]
GO

/****** Object:  View [dbo].[vi_BTI_CountTime]    Script Date: 01/03/2019 22:51:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--������ͼ
create view [dbo].[vi_BTI_CountTime]
as
	select StaffInfo.name as '����', COUNT(*) as '�������'
	from BusinessTripInfo inner join StaffInfo
	on BusinessTripInfo.id = StaffInfo.id
	group by BusinessTripInfo.id, StaffInfo.name

GO


--��������ܼ���ͼ
USE [db_StaffInfo]
GO

/****** Object:  View [dbo].[vi_BTI_TotalAllowance]    Script Date: 01/03/2019 22:52:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create view [dbo].[vi_BTI_TotalAllowance]
as
	select StaffInfo.name as '����', sum(BusinessTripInfo.allowance)
		as '��������ܼ�' from BusinessTripInfo inner join StaffInfo
		on BusinessTripInfo.id = StaffInfo.id
		group by BusinessTripInfo.id, StaffInfo.name

GO


--������ٴ�����ͼ
USE [db_StaffInfo]
GO

/****** Object:  View [dbo].[vi_LI_CountTime]    Script Date: 01/03/2019 22:52:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create view [dbo].[vi_LI_CountTime]
as
	select StaffInfo.name as '����', 
		COUNT(*) as '��ٴ���'
	from LeaveInfo inner join StaffInfo
	on LeaveInfo.id = StaffInfo.id
	group by LeaveInfo.id, StaffInfo.name

GO


--������ٹ���������ͼ
USE [db_StaffInfo]
GO

/****** Object:  View [dbo].[vi_LI_TotalDeduction]    Script Date: 01/03/2019 22:52:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create view [dbo].[vi_LI_TotalDeduction]
as
	select StaffInfo.name as '����', 
	SUM(LeaveInfo.deduction) as '��ٹ��������ܼ�' from 
	StaffInfo inner join LeaveInfo
	on StaffInfo.id = LeaveInfo.id
	group by StaffInfo.name, LeaveInfo.id

GO


--����Ӱ������ͼ
USE [db_StaffInfo]
GO

/****** Object:  View [dbo].[vi_OTI_countTime]    Script Date: 01/03/2019 22:53:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create view [dbo].[vi_OTI_countTime]
as 
	select StaffInfo.name as '����',
	COUNT(*) as '�Ӱ����' from OverTimeInfo inner join StaffInfo
	on OverTimeInfo.id = StaffInfo.id 
	group by OverTimeInfo.id, StaffInfo.name

GO


--�Ӱ๤���ܼ���ͼ
USE [db_StaffInfo]
GO

/****** Object:  View [dbo].[vi_OTI_TotalWage]    Script Date: 01/03/2019 22:53:49 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create view [dbo].[vi_OTI_TotalWage]
as
	select StaffInfo.name as '����',
	sum(OverTimeInfo.overTimeWage) as '�Ӱ๤���ܼ�'
	from StaffInfo inner join OverTimeInfo
	on StaffInfo.id = OverTimeInfo.id
	group by StaffInfo.name, OverTimeInfo.id

GO


--ְ����Ϣ��ͼ
USE [db_StaffInfo]
GO

/****** Object:  View [dbo].[vi_SI]    Script Date: 01/03/2019 22:54:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vi_SI]
AS
SELECT     name AS ����, id AS ְ�����, sex AS �Ա�, birthday AS ��������, title AS ְ��
FROM         dbo.StaffInfo

GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "StaffInfo"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 126
               Right = 180
            End
            DisplayFlags = 280
            TopColumn = 1
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SI'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SI'
GO




--������ͼ
USE [db_StaffInfo]
GO

/****** Object:  View [dbo].[vi_SI_BT]    Script Date: 01/03/2019 22:55:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vi_SI_BT]
AS
SELECT     dbo.StaffInfo.name AS ����, dbo.BusinessTripInfo.start AS ��ʼʱ��, dbo.BusinessTripInfo.endTime AS ����ʱ��, dbo.BusinessTripInfo.total AS ������, 
                      dbo.BusinessTripInfo.allowance AS �������
FROM         dbo.StaffInfo INNER JOIN
                      dbo.BusinessTripInfo ON dbo.StaffInfo.id = dbo.BusinessTripInfo.id

GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "StaffInfo"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 126
               Right = 180
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "BusinessTripInfo"
            Begin Extent = 
               Top = 6
               Left = 218
               Bottom = 126
               Right = 360
            End
            DisplayFlags = 280
            TopColumn = 1
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SI_BT'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SI_BT'
GO


--��˾��������ͼ
USE [db_StaffInfo]
GO

/****** Object:  View [dbo].[vi_SI_countPeople]    Script Date: 01/03/2019 22:55:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create view [dbo].[vi_SI_countPeople]
as
	select COUNT(*) as '��˾ְ��������'
	from StaffInfo

GO


--�����ͼ
USE [db_StaffInfo]
GO

/****** Object:  View [dbo].[vi_SI_LI]    Script Date: 01/03/2019 22:56:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vi_SI_LI]
AS
SELECT     dbo.StaffInfo.name AS ����, dbo.LeaveInfo.start AS ��ʼʱ��, dbo.LeaveInfo.endTime AS ����ʱ��, dbo.LeaveInfo.total AS ������, dbo.LeaveInfo.deduction AS �������
FROM         dbo.StaffInfo INNER JOIN
                      dbo.LeaveInfo ON dbo.StaffInfo.id = dbo.LeaveInfo.id

GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "StaffInfo"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 126
               Right = 180
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "LeaveInfo"
            Begin Extent = 
               Top = 6
               Left = 218
               Bottom = 126
               Right = 360
            End
            DisplayFlags = 280
            TopColumn = 1
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SI_LI'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SI_LI'
GO


--�Ӱ���ͼ
USE [db_StaffInfo]
GO

/****** Object:  View [dbo].[vi_SI_OTI]    Script Date: 01/03/2019 22:56:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vi_SI_OTI]
AS
SELECT     dbo.StaffInfo.name AS ����, dbo.OverTimeInfo.start AS ��ʼʱ��, dbo.OverTimeInfo.endTime AS ����ʱ��, dbo.OverTimeInfo.total AS ��ʱ��, dbo.OverTimeInfo.overTimeWage AS �Ӱಹ��
FROM         dbo.StaffInfo INNER JOIN
                      dbo.OverTimeInfo ON dbo.StaffInfo.id = dbo.OverTimeInfo.id

GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "StaffInfo"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 126
               Right = 180
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "OverTimeInfo"
            Begin Extent = 
               Top = 6
               Left = 218
               Bottom = 126
               Right = 379
            End
            DisplayFlags = 280
            TopColumn = 1
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SI_OTI'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SI_OTI'
GO


--�û���ͼ
USE [db_StaffInfo]
GO

/****** Object:  View [dbo].[vi_SI_UI]    Script Date: 01/03/2019 22:57:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vi_SI_UI]
AS
SELECT     dbo.StaffInfo.name AS ����, dbo.UserInfo.Tel AS �ֻ���, dbo.UserInfo.id AS ְ�����
FROM         dbo.StaffInfo INNER JOIN
                      dbo.UserInfo ON dbo.StaffInfo.id = dbo.UserInfo.id

GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "StaffInfo"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 126
               Right = 180
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "UserInfo"
            Begin Extent = 
               Top = 6
               Left = 218
               Bottom = 126
               Right = 360
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SI_UI'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SI_UI'
GO


--������ͼ
USE [db_StaffInfo]
GO

/****** Object:  View [dbo].[vi_SI_WAI]    Script Date: 01/03/2019 22:57:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vi_SI_WAI]
AS
SELECT     dbo.StaffInfo.name AS ����, dbo.WorkAttendanceInfo.goToWork AS �ϰ��ʱ��, dbo.WorkAttendanceInfo.knockOff AS �°��ʱ��
FROM         dbo.StaffInfo INNER JOIN
                      dbo.WorkAttendanceInfo ON dbo.StaffInfo.id = dbo.WorkAttendanceInfo.id

GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "StaffInfo"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 126
               Right = 180
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "WorkAttendanceInfo"
            Begin Extent = 
               Top = 6
               Left = 218
               Bottom = 111
               Right = 360
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SI_WAI'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SI_WAI'
GO


--������ͼ
USE [db_StaffInfo]
GO

/****** Object:  View [dbo].[vi_SI_WAI_Table]    Script Date: 01/03/2019 22:58:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vi_SI_WAI_Table]
AS
SELECT     dbo.StaffInfo.name AS ����, dbo.StaffInfo.id AS ְ�����, dbo.WorkAttendanceInfo.goToWork AS �ϰ��ʱ��, dbo.WorkAttendanceInfo.knockOff AS �°��ʱ��
FROM         dbo.StaffInfo INNER JOIN
                      dbo.WorkAttendanceInfo ON dbo.StaffInfo.id = dbo.WorkAttendanceInfo.id

GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "StaffInfo"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 126
               Right = 180
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "WorkAttendanceInfo"
            Begin Extent = 
               Top = 6
               Left = 218
               Bottom = 111
               Right = 360
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SI_WAI_Table'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SI_WAI_Table'
GO


--������ͼ
USE [db_StaffInfo]
GO

/****** Object:  View [dbo].[vi_SIWI_wage]    Script Date: 01/03/2019 22:58:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vi_SIWI_wage]
AS
SELECT     dbo.StaffInfo.name AS ����, dbo.StaffInfo.id AS ְ�����, dbo.WageInfo.base AS ��н, dbo.WageInfo.overTimeWage AS �Ӱಹ��, dbo.WageInfo.absentDeduction AS ȱ������, 
                      dbo.WageInfo.leaveDeduction AS �������, dbo.WageInfo.allowance AS �������, dbo.WageInfo.total AS �ܼ�, dbo.WageInfo.start AS ��ʼʱ��, dbo.WageInfo.endTime AS ����ʱ��
FROM         dbo.StaffInfo INNER JOIN
                      dbo.WageInfo ON dbo.StaffInfo.id = dbo.WageInfo.id

GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "StaffInfo"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 126
               Right = 180
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "WageInfo"
            Begin Extent = 
               Top = 6
               Left = 218
               Bottom = 126
               Right = 388
            End
            DisplayFlags = 280
            TopColumn = 5
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SIWI_wage'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'vi_SIWI_wage'
GO

--ȱ�ڴ���ͳ�ƴ洢����
USE [db_StaffInfo]
GO

/****** Object:  StoredProcedure [dbo].[absentCount]    Script Date: 01/03/2019 22:59:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE proc [dbo].[absentCount]
(@id char(6), @start datetime, @end datetime, @result int output)
as
	declare @total int
	set @total = DATEDIFF(day, @start, @end) + 1
	declare @count int
	select @count = COUNT(*) from WorkAttendanceInfo
	where @id = id and @start <= goToWork and @end >= goToWork
	set @result = @total - @count
	
	



GO


--�Զ����¹����ܼƴ洢����
USE [db_StaffInfo]
GO

/****** Object:  StoredProcedure [dbo].[autoWage]    Script Date: 01/03/2019 23:00:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE  [dbo].[autoWage] 
as
BEGIN
	--�����α�
	declare c1 cursor for select id, start, endTime from WageInfo
	--���α�
	open c1
	declare @id char(6)
	declare @start datetime
	declare @endTime datetime
			fetch next from c1 into @id, @start, @endTime
			while @@FETCH_STATUS = 0
			begin 
				--��ÿһ��id���и���ȱ��
				declare @result int
				exec absentCount @id, @start, @endTime, @result output 
				--����ȱ������
				declare @absentDeduction money
				set @absentDeduction = 200 * @result
				--���¼�¼
				update WageInfo
				set absentDeduction = @absentDeduction
				where @id = id
			fetch next from c1 into @id, @start, @endTime
			end
			--�ر��α�
			close c1
			--�ͷ��α�
			deallocate c1
END

GO


--��ȡ�û����ʹ洢����
USE [db_StaffInfo]
GO

/****** Object:  StoredProcedure [dbo].[getType]    Script Date: 01/03/2019 23:00:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getType] (@id char(6), @userType bit output)
as
BEGIN
	if exists(select * from StaffInfo where @id = id and title in('���²�����Ա', '���ݿ����Ա'))
		set @userType = 1
	else
		set @userType = 0
END

GO


--ͨ���ֻ���ȡ�û����ʹ洢����
USE [db_StaffInfo]
GO

/****** Object:  StoredProcedure [dbo].[getTypeByTel]    Script Date: 01/03/2019 23:01:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getTypeByTel]
(@Tel char(11), @type bit output)
AS
BEGIN
	select @type = userType from UserInfo where
	Tel = @Tel
END

GO


--�ж�id�Ƿ��Ѵ��ڴ洢����
USE [db_StaffInfo]
GO

/****** Object:  StoredProcedure [dbo].[isExistId]    Script Date: 01/03/2019 23:01:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[isExistId](@id char(6), @result bit output)
as
BEGIN
	if exists(select * from StaffInfo where id = @id)
		set @result = 1
	else
		set @result = 0
END

GO


--�ж��ֻ����Ƿ��Ѵ��ڵĴ洢����
USE [db_StaffInfo]
GO

/****** Object:  StoredProcedure [dbo].[isExistTel]    Script Date: 01/03/2019 23:02:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[isExistTel] (@tel char(11), @result bit output)
as
BEGIN
	if exists(select * from UserInfo where UserInfo.Tel = @tel)
		set @result = 1
	else
		set @result = 0
END

GO


--�ж��û��Ƿ��Ѵ��ڵĴ洢����
USE [db_StaffInfo]
GO

/****** Object:  StoredProcedure [dbo].[isExistUser]    Script Date: 01/03/2019 23:02:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[isExistUser] (@Tel char(11),
@passWd char(16), @result bit output)
as
BEGIN
	if exists(select * from UserInfo where @Tel = Tel and @passWd = passWd)
		set @result = 1
	else
		set @result = 0
END

GO



