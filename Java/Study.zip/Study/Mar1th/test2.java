public class test2
{
	public static void main(String[] args)
	{
		System.out.println("25/4的结果是:" + 25 / 4);
		System.out.println("25/4的浮点数结果是:" + 25.0 / 4);
	}
}
