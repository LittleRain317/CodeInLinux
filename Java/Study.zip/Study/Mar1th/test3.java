public class test3
{
	public static void main(String[] args)
	{
		System.out.println("22乘以8等于:" + 22 * 8);
	}
}
