public class test6
{
	public static void main(String[] args)
	{
		int i = 128;
		i = 100008;//整数太大
		System.out.println(i);
	}
}
