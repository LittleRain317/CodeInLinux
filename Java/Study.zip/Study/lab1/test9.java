public class test9
{
	public static void main(String[] args)
	{
		char ascii = 98;
		System.out.println(ascii);
	}
}
