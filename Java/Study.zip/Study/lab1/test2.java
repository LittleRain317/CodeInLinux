public class test2
{
	public static void main(String[] args)
	{
		int size = 20;
		System.out.println(size);
	}
}
