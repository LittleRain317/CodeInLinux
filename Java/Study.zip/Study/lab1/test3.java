public class test3
{
	public static void main(String[] args)
	{
		int age = 0;
		System.out.println(age);
	}
}
