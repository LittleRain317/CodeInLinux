public class test10
{
	public static void main(String[] args)
	{
		byte b1 = 10;
		byte b2 = 20;
		byte b3 = (byte)(b1 + b2);
	}
}
