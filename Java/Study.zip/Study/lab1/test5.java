public class test5
{
	public static void main(String[] args)
	{
		int balance = 0;
		balance = (int)218.50;
	}
}
