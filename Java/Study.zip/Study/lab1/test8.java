public class test8
{
	public static void main(String[] args)
	{
		double width = 6.0;
		double length = 4.9;
		System.out.println(width - length);
	}
}
