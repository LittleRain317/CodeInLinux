public class test1
{
	public static void main(String[] args)
	{
		int length = 10;
		System.out.println(length);
	}
}
