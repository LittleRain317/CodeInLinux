public class test4
{
	public static void main(String[] args)
	{
		int count = 30;
		count = 60;
		System.out.println(count);
	}
}
